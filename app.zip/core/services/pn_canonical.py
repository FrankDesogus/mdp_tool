# core/services/pn_canonical.py
from __future__ import annotations
import re
from typing import Optional

# rimuove spazi e separatori interni tipici
_SEP_RE = re.compile(r"[\s\-_\/\.]+")

def canonicalize_rev(rev: str) -> str:
    return (rev or "").strip().upper()

def canonicalize_pn(code: str, *, rev: Optional[str] = None) -> str:
    """
    Canonical PN:
      - uppercase
      - rimuove spazi e separatori: 'E0224103 01' -> 'E022410301'
      - se rev è disponibile e il PN termina con quella rev, rimuove la rev finale:
          code='E022410301', rev='01' -> 'E0224103'
    Nota: la rimozione della rev è conservativa (solo se rev presente).
    """
    c = (code or "").strip().upper()
    if not c:
        return ""
    c = _SEP_RE.sub("", c)

    r = canonicalize_rev(rev or "")
    if r and len(r) <= 4 and len(c) > len(r) + 2 and c.endswith(r):
        c = c[: -len(r)]

    return c
