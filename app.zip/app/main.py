# app/main.py
def main():
    print("mdp_tool avviato (debug)")
    # Qui più avanti avvieremo la GUI PySide/PyQt

if __name__ == "__main__":
    main()
