# analyze_folder_pdf_.py
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Set, Tuple

from core.parsers.bom_pdf import parse_bom_pdf_raw
from core.services.exploder import explode_boms, ExplodePolicy
from core.domain.models import BomDocument, key_code_rev

# Qui presumo tu abbia già queste (le usi in analyze_folder.py):
from core.services.discovery import discover_project_files
from core.services.bom_normalizer import build_bom_document  # <- stessa che usi per Excel


@dataclass
class PdfFolderAnalysisResult:
    folder: Path
    bom_paths: List[Path] = field(default_factory=list)
    boms: List[BomDocument] = field(default_factory=list)

    roots: List[Tuple[str, str]] = field(default_factory=list)  # (code, rev)
    explosions: Dict[Tuple[str, str], object] = field(default_factory=dict)

    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


def _norm(s: str) -> str:
    return (s or "").strip().upper()


def infer_roots_from_boms(boms: List[BomDocument]) -> List[Tuple[str, str]]:
    """
    Root inference BOM-only:
    root_codes = header_codes - children_codes
    Ritorna lista di (code, rev) per cui esiste BOM e non compare mai come child.
    """
    header_keys: List[Tuple[str, str]] = []
    header_codes: Set[str] = set()
    child_codes: Set[str] = set()

    for b in boms:
        hc = _norm(b.header.code)
        hr = _norm(b.header.revision)
        header_keys.append((hc, hr))
        header_codes.add(hc)

        for ln in b.lines:
            cc = _norm(getattr(ln, "internal_code", "") or "")
            if cc:
                child_codes.add(cc)

    root_codes = sorted(header_codes - child_codes)

    # se ci sono più rev per lo stesso code, prendi tutte (o scegli max-rev se preferisci)
    roots: List[Tuple[str, str]] = []
    for code in root_codes:
        revs = [rev for (c, rev) in header_keys if c == code]
        if not revs:
            continue
        # default: tutte le rev trovate
        for r in sorted(set(revs)):
            roots.append((code, r))

    return roots


class AnalyzeFolderPdfUseCase:
    def run(self, folder: Path) -> PdfFolderAnalysisResult:
        folder = Path(folder)
        res = PdfFolderAnalysisResult(folder=folder)

        discovery = discover_project_files(folder)
        # qui dipende dal tuo discovery: in analyze_folder.py avevi discovery.boms ecc.
        # io assumo che tu abbia un elenco Path BOM pdf
        bom_pdf_paths = [p for p in discovery.boms if p.suffix.lower() == ".pdf"]

        res.bom_paths = bom_pdf_paths

        # 1) Parse + build BomDocument
        for p in bom_pdf_paths:
            try:
                raw = parse_bom_pdf_raw(p)
                bom_doc = build_bom_document(raw=raw, path=p)  # stessa firma che usi per excel
                res.boms.append(bom_doc)
            except Exception as e:
                res.errors.append(f"Parse/build BOM PDF fallita: {p.name}: {type(e).__name__}: {e}")

        if not res.boms:
            res.errors.append("Nessuna BOM PDF parseata correttamente: impossibile procedere.")
            return res

        # 2) Root inference BOM-only
        res.roots = infer_roots_from_boms(res.boms)
        if not res.roots:
            # fallback: se non riesci a dedurre root, prendi tutte le BOM come root candidate
            res.warnings.append("Root inference: nessuna root dedotta. Uso tutte le BOM come root candidate.")
            res.roots = [(_norm(b.header.code), _norm(b.header.revision)) for b in res.boms]

        # 3) Explode
        policy = ExplodePolicy(
            strict_rev=True,
            explode_documents=False,
            root_strict_rev=True,          # qui abbiamo (code,rev) da header -> ok
            recursive_fallback=True,
            recursive_pick_highest_rev=True,
        )

        # indicizza boms una sola volta
        bom_index = {key_code_rev(b.header.code, b.header.revision): b for b in res.boms}

        for (root_code, root_rev) in res.roots:
            # se la root (code,rev) non è presente (case mismatch), prova a recuperarla
            if (root_code, root_rev) not in bom_index:
                # fallback semplice: prova solo per code
                cands = [b for b in res.boms if _norm(b.header.code) == root_code]
                if cands:
                    chosen = max(cands, key=lambda b: _norm(b.header.revision))
                    root_rev = _norm(chosen.header.revision)
                else:
                    res.warnings.append(f"Root {root_code} {root_rev} non trovata nel dataset, skip.")
                    continue

            exp = explode_boms(
                root_code=root_code,
                root_rev=root_rev,
                boms=res.boms,
                pbs=None,          # BOM-only
                policy=policy,
            )
            res.explosions[(root_code, root_rev)] = exp

        return res
