# core/parsers/bom_pdf.py  (patch consigliata)

from pathlib import Path
import re
import pdfplumber

HEADER_RE = {
    "code": re.compile(r"Code\s*:\s*(.+)"),
    "rev": re.compile(r"Revision\s*:\s*(.+)"),
    "title": re.compile(r"Description\s*:\s*(.+)"),
    "date": re.compile(r"Printing Date\s*:\s*(\d{2}/\d{2}/\d{4})"),
}

def _parse_qty(v) -> float | None:
    if v is None:
        return None
    s = str(v).strip()
    if not s:
        return None
    # gestisci "1,5" e "1.000,25" ecc.
    if "." in s and "," in s:
        s = s.replace(".", "").replace(",", ".")
    else:
        s = s.replace(",", ".")
    try:
        return float(s)
    except Exception:
        return None

def parse_bom_pdf_raw(path: Path) -> dict:
    header = {"code": "", "rev": "", "title": "", "date": ""}
    lines = []

    with pdfplumber.open(path) as pdf:
        first_page = pdf.pages[0]
        text = first_page.extract_text() or ""

        # --- header ---
        for key, rx in HEADER_RE.items():
            m = rx.search(text)
            if m:
                header[key] = m.group(1).strip()

        # normalizza data
        if header["date"]:
            d, m, y = header["date"].split("/")
            header["date"] = f"{y}-{m}-{d}"

        # --- table ---
        for page in pdf.pages:
            tables = page.extract_tables() or []
            for table in tables:
                for row in table:
                    if not row:
                        continue

                    pos_raw = (row[0] or "").strip()
                    if not pos_raw.isdigit():
                        continue

                    # N.B. qui mantengo i tuoi indici originali, ma ora normalizzo le chiavi
                    internal_code = (row[2] or "").strip()
                    rev = (row[3] or "").strip()
                    description = (row[4] or "").strip()
                    um = (row[8] or "").strip()
                    qty = _parse_qty(row[9])

                    lines.append({
                        "pos": pos_raw.zfill(4),
                        "internal_code": internal_code,
                        "rev": rev,
                        "description": description,
                        "um": um,
                        "qty": qty,

                        # campi extra (se vuoi conservarli)
                        "ref_schema": (row[5] or "").strip() if len(row) > 5 else "",
                        "ref_dis": (row[6] or "").strip() if len(row) > 6 else "",
                        "ref_access": (row[7] or "").strip() if len(row) > 7 else "",
                        "note": (row[10] or "").strip() if len(row) > 10 else "",
                        "ce": (row[11] or "").strip() if len(row) > 11 else "",
                        "mp": (row[12] or "").strip() if len(row) > 12 else "",
                        "manufacturer_code": (row[13] or "").strip() if len(row) > 13 else "",
                        "manufacturer": (row[14] or "").strip() if len(row) > 14 else "",
                    })

    if not header["code"]:
        raise ValueError(f"BOM PDF senza header riconoscibile: {path.name}")

    return {"header": header, "lines": lines, "warnings": []}
