# mdp_tool/core/parsers/discovery.py
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List, Tuple, Iterable
import os


EXCEL_EXT = {".xls", ".xlsx", ".xlsm"}
PDF_EXT = {".pdf"}


@dataclass(frozen=True)
class DiscoveryResult:
    base_dir: Path
    pbs_candidates: Tuple[Path, ...]
    bom_excel: Tuple[Path, ...]
    bom_pdf: Tuple[Path, ...]


def _is_excel(p: Path) -> bool:
    return p.suffix.lower() in EXCEL_EXT


def _is_pdf(p: Path) -> bool:
    return p.suffix.lower() in PDF_EXT


def _name_has(p: Path, needle: str) -> bool:
    return needle.lower() in p.name.lower()


def _safe_scandir(dir_path: Path):
    """os.scandir wrapper that won't blow up on permissions / network hiccups."""
    try:
        with os.scandir(dir_path) as it:
            for entry in it:
                yield entry
    except Exception:
        return


def _should_skip_dir(name: str, skip_names: Iterable[str]) -> bool:
    n = (name or "").strip().lower()
    if not n:
        return False
    if n in skip_names:
        return True
    # hidden-ish / noisy
    if n.startswith("~$"):
        return True
    return False


def discover_folder(base_dir: str | Path) -> DiscoveryResult:
    """
    Scansiona (controllato, adatto a filesystem di rete):
    - PBS: file excel con 'PBS' nel nome
    - BOM Excel: excel con 'PRT LIST' o 'PART LIST' nel nome
    - BOM PDF: pdf con 'BOM' nel nome

    Fix performance/stability:
    - evita rglob("*") su share grandi
    - limita profondità (max_depth)
    - skip directory note
    - gestisce eccezioni IO/permessi senza bloccare
    - early-stop: se trovato 1 PBS e abbastanza BOM, si può fermare
    """
    base = Path(base_dir).expanduser().resolve()
    if not base.exists() or not base.is_dir():
        raise FileNotFoundError(f"Cartella non valida: {base}")

    # ---- knobs (keep conservative defaults) ----
    max_depth = 4  # 0=solo base, 1=base+figli, ...
    # directory da saltare (aggiungi qui ciò che nella tua share è enorme/inutile)
    skip_dir_names = {
        ".git", ".svn", "__pycache__", "node_modules",
        "_diagnostics", "_odoo_export",
    }
    # early stop (non blocca: serve solo a non scansionare tutto se non serve)
    max_bom_excel = 8000
    max_bom_pdf = 8000
    stop_when_found_pbs_and_boms = True
    min_boms_to_stop = 200  # quando trovi un PBS e almeno questo numero di BOM, fermati

    pbs: List[Path] = []
    bom_xls: List[Path] = []
    bom_pdf: List[Path] = []

    # BFS stack: (dir_path, depth)
    stack: List[Tuple[Path, int]] = [(base, 0)]

    while stack:
        cur_dir, depth = stack.pop()
        if depth > max_depth:
            continue

        for entry in _safe_scandir(cur_dir):
            try:
                name = entry.name
            except Exception:
                continue

            # directory handling
            try:
                if entry.is_dir(follow_symlinks=False):
                    if _should_skip_dir(name, skip_dir_names):
                        continue
                    # push next
                    stack.append((Path(entry.path), depth + 1))
                    continue
            except Exception:
                continue

            # file handling
            try:
                if not entry.is_file(follow_symlinks=False):
                    continue
                p = Path(entry.path)
            except Exception:
                continue

            # collect
            try:
                if _is_excel(p) and _name_has(p, "PBS"):
                    pbs.append(p)
                elif _is_excel(p) and (_name_has(p, "PRT LIST") or _name_has(p, "PART LIST")):
                    bom_xls.append(p)
                elif _is_pdf(p) and _name_has(p, "BOM"):
                    bom_pdf.append(p)
            except Exception:
                # in caso di nomi strani / path issues
                continue

            # hard caps (avoid runaway memory on huge shares)
            if len(bom_xls) >= max_bom_excel:
                # stop collecting more xls; but continue to find PBS (and maybe pdf)
                pass
            if len(bom_pdf) >= max_bom_pdf:
                pass

        # early stop condition
        if stop_when_found_pbs_and_boms and len(pbs) >= 1:
            if (len(bom_xls) + len(bom_pdf)) >= min_boms_to_stop:
                break

    # ordinamento stabile
    pbs.sort(key=lambda x: x.as_posix().lower())
    bom_xls.sort(key=lambda x: x.as_posix().lower())
    bom_pdf.sort(key=lambda x: x.as_posix().lower())

    return DiscoveryResult(
        base_dir=base,
        pbs_candidates=tuple(pbs),
        bom_excel=tuple(bom_xls),
        bom_pdf=tuple(bom_pdf),
    )


def choose_single_pbs(discovery: DiscoveryResult) -> Path:
    """
    Regola: non scegliere mai "a caso".
    Se 0 -> errore
    Se >1 -> errore (ambiguità)
    """
    if len(discovery.pbs_candidates) == 0:
        raise RuntimeError("Nessun file PBS trovato nella cartella.")
    if len(discovery.pbs_candidates) > 1:
        msg = "Trovati più file PBS (ambiguità):\n" + "\n".join(str(p) for p in discovery.pbs_candidates)
        raise RuntimeError(msg)
    return discovery.pbs_candidates[0]
