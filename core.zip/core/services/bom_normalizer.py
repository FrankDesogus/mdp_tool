# mdp_tool/core/services/bom_normalizer.py
from __future__ import annotations

import math
import re
from pathlib import Path
from typing import Optional, Iterable, List

from core.domain.models import (
    BomLineKind,
    NormalizedBomLine,
    BomHeader,
    BomDocument,
)

# ✅ NEW: alias/canonicalizzazione codici (external -> internal)
from core.services.code_aliases import canonicalize_code


# --- regole base, estendibili ---
_REF_UNITS = {"REF", "REFERENCE", "DOC", "DOCUMENT", "DWG"}


def parse_qty(value) -> Optional[float]:
    """
    Parsing robusto quantità:
    - None / "" / "-" => None
    - numeri excel -> float
    - stringhe "1,00" "1.00" " 2 " => float
    - stringhe non numeriche => None
    """
    if value is None:
        return None

    if isinstance(value, float) and math.isnan(value):
        return None

    if isinstance(value, (int, float)):
        return float(value)

    s = str(value).strip()
    if not s or s == "-":
        return None

    # normalizza "1,00" -> "1.00"
    s = s.replace(",", ".")
    # rimuovi spazi e caratteri non numerici "soft" (es. "1.00 ")
    s = re.sub(r"\s+", "", s)

    try:
        return float(s)
    except ValueError:
        return None


def normalize_unit(u: Optional[str]) -> str:
    return (u or "").strip().upper()


def classify_line(qty: Optional[float], unit: str) -> BomLineKind:
    """
    Regole:
    - UM in REF_UNITS => DOCUMENT_REF (anche se qty manca)
    - qty è None => DOCUMENT_REF se unit è REF-like, altrimenti UNKNOWN
    - qty presente => MATERIAL (anche se unit vuota, ma warning lo gestirai altrove)
    """
    if unit in _REF_UNITS:
        return BomLineKind.DOCUMENT_REF
    if qty is None:
        return BomLineKind.UNKNOWN
    return BomLineKind.MATERIAL


from typing import Iterable, List, Optional
from pathlib import Path

def build_bom_document(
    *,
    path: Path,
    header_code: str,
    header_rev: str,
    header_title: str = "",
    doc_date_iso: str = "",
    raw_lines: Iterable[dict],
) -> BomDocument:
    # ✅ NEW: canonicalizza header_code (codice esterno -> codice interno)
    header_code = canonicalize_code((header_code or "").strip())

    header = BomHeader(
        code=(header_code or "").strip(),
        revision=(header_rev or "").strip(),
        title=(header_title or "").strip(),
        doc_date_iso=(doc_date_iso or "").strip(),
    )

    lines: List[NormalizedBomLine] = []

    for raw_line in raw_lines:
        if not isinstance(raw_line, dict):
            raise TypeError(f"BOM normalizer: riga non-dict: {type(raw_line)!r}")

        pos = str(raw_line.get("pos") or "").strip()

        # component code nella tabella = INTERNAL CODE
        internal_code = str(
            raw_line.get("internal_code")
            or raw_line.get("code")          # fallback eventuale
            or ""
        ).strip()

        # ✅ NEW: canonicalizza internal_code (codice esterno -> codice interno)
        if internal_code:
            internal_code = canonicalize_code(internal_code)

        description = str(raw_line.get("description") or "").strip()
        rev = str(raw_line.get("rev") or "").strip()

        unit = normalize_unit(raw_line.get("um") or raw_line.get("unit"))
        qty = parse_qty(raw_line.get("qty"))

        kind = classify_line(qty, unit)

        # extra colonne reali del tuo Excel
        val = str(raw_line.get("val") or "").strip()
        rat = str(raw_line.get("rat") or "").strip()
        tol = str(raw_line.get("tol") or "").strip()
        refdes = str(raw_line.get("refdes") or "").strip()
        tecn = str(raw_line.get("tecn") or "").strip()
        notes = str(raw_line.get("notes") or "").strip()

        manufacturer = str(raw_line.get("manufacturer") or "").strip()
        manufacturer_code = str(raw_line.get("manufacturer_code") or "").strip()

        lines.append(
            NormalizedBomLine(
                pos=pos,
                internal_code=internal_code,
                description=description,
                qty=qty,
                unit=unit,
                kind=kind,
                val=val,
                rat=rat,
                tol=tol,
                refdes=refdes,
                tecn=tecn,
                notes=notes,
                manufacturer=manufacturer,
                manufacturer_code=manufacturer_code,
                rev=rev,
            )
        )

    return BomDocument(
        path=path,
        header=header,
        lines=lines,
    )
